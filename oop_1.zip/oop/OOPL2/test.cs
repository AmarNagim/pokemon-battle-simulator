using System;
class Program{
// Type your username and press enter
Console.WriteLine("Enter username:");

// Create a string variable and get user input from the keyboard and store it in the variable
string userName = Console.ReadLine();

// Print the value of the variable (userName), which will display the input value
Console.WriteLine("Username is: " + userName);


}
// hier wordt de charmander gemaakt met de bepaalde values 
class Charmander{

    public string type;
    public string name;
    public string strenght;
    public string weakness;
    public string attacks;

    public void setAtributes(){

        this.type = type;
        this.name = name;
        this.weakness = weakness;
        this.strenght = strenght;
        this.attacks = attacks;
    }


}